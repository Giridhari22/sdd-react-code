const productModel = require("../models/productModels");

const {Op} = require("sequelize")


exports.addProducts = async (req, res) => {
    try {
        const { productName, productPrice, category } = req.body;
        // console.log(req.body);
        const Seq = await productModel.create({ productName, productPrice, category })
        res.json({ Seq })
        console.log(Seq)
    } catch (error) {
        console.log(error)
    }
}

exports.getProducts = async (req, res) => {
    try {

        const data = await productModel.findAll();
        res.status(200).json({ data: data })
        console.log(data)

    } catch (error) {
        console.log(error)
    }

}

exports.searchapi = async(req,res) =>{
    try {
        
        const {productName} = req.query;
        console.log(req.query)
    
        const results = await productModel.findAll({
            where:{
                productName:{
                    [Op.like]: `%${productName}%`
                }
    
            }
        })
        return res.json({success : true, products : results})
    } catch (error) {
        
    }
}


