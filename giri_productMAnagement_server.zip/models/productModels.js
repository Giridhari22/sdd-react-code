const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require("../config/db");

const productModel = sequelize.define('giri_productModel', {
  // Model attributes are defined here
  productName: {
    type: Sequelize.STRING,
    allowNull: false
  },
  productPrice: {
    type: Sequelize.INTEGER,
    allowNull: false
    // allowNull defaults to true
  },
 
  category:{
    type: Sequelize.STRING,
    allowNull: false,
   
  }
  
});
module.exports = productModel;