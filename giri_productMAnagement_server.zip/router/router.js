const { addProducts, getProducts ,searchapi , editProducts} = require('../controllers/productsController');

const router = require('express').Router();

  
  



router.get('/',(req,res)=>{
    res.send("product ban gaya")
})


// for creating user
router.post('/addProducts', addProducts);

// for getting products
router.get('/getProducts', getProducts);

// for search api
router.get('/searchapi', searchapi)



module.exports = router















module.exports = router;