const productModel = require("../models/productModels");


const sync=async()=>{
   await productModel.sync();
}


module.exports.SyncModels=sync
