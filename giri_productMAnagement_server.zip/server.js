const express = require("express");
const server = express();
require("./config/db") // sirf hame require karna hai .. so that ki file ko le paye
const bodyParser = require('body-parser'); 
const cors = require('cors');
const appRoute = require('./router/router')
PORT = 5000;

server.use(cors());
// server.use("/public",express.static('public'))

server.use(bodyParser.urlencoded({ extended: false }));
server.use(bodyParser.json())
server.use(express.urlencoded({ extended: false }));
// server.use("/uploads", express.static("uploads"))



// Routes declaration
server.use('/api',appRoute)


server.listen(PORT, () =>
    console.log('Example app listening on port'+PORT),
  );