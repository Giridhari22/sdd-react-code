import React, {  useState } from 'react';
import ProductClass from './Components/ProductClass';
import ProductFunc from './Components/ProductFunc';






const App = () => {
  const [isClassComponent, setIsClassComponent] = useState(true);

  const toggleComponent = () => {
    setIsClassComponent(!isClassComponent);
  };

  return (
    <div>
      {isClassComponent ? (
        <ProductFunc />
      ) : (
        <ProductClass />
      )}
      
     <center>

      <button type="button" class="btn btn-primary" onClick={toggleComponent}>Switch Component</button>
     </center>
    </div>
  );
};

export default App;
