import React, { Component } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Form, Row } from 'react-bootstrap';
import axios from 'axios';
import Table from 'react-bootstrap/Table';
import { MDBCol } from "mdbreact";
import LoadingSpinner from "./LoadingSpinner";


export class ProductClass extends Component {
    constructor() {
        super()
        this.state = {
            url: "http://localhost:5000/api/",
            data: [],
            searchInput: '',
            productName: '',
            productPrice: '',
            category: '',
            loading:false
        }
    }


    handleSubmit = (event) => {
        event.preventDefault();
        this.setState({loading:true});
        // jo backend se data aayega usko rakhega wo
        axios.post('http://localhost:5000/api/addProducts', { productName: this.state.productName, productPrice: this.state.productPrice, category: this.state.category })
            .then(res => {
                console.log(res)
                this.fetchInfo();
                this.setState({loading:false});
            })
            .catch(err => console.log(err));
            this.setState({loading:false});
            setTimeout(() => {
                this.setState({loading:false});
            }, 2000)
    
    }
    fetchInfo = () => {
        return axios.get(this.state.url + "getProducts")
            .then((response) => {
                console.log(response.data);
                this.setState({ data: response.data.data })
            }).catch((err) => console.log(err))
    }

    componentDidMount() {
        this.fetchInfo()
    }

    componentDidUpdate = async (prevProps, prevState) => {
        if (prevState.searchInput !== this.state.searchInput) {
            try {
                
                const res = await axios.get(`http://localhost:5000/api/searchapi?productName=${this.state.searchInput.toLowerCase()}`);
                console.log(res.data)
                this.setState({data:res.data.products})

            } catch (error) {
                console.log(error)
            }
        }

    }




    render() {
        return (
            <>
                <h1>class based components</h1>
                <form className="container mt-3 mb-3" onSubmit={this.handleSubmit}>
                    <Row className="mb-3">
                        <Form.Group controlId="formBasicEmail" className="col col-sm-4">
                            <Form.Label>Product Name</Form.Label>
                            <Form.Control type="name" name="first_name" onChange={e => this.setState({ productName: e.target.value })} className="form-control" />
                        </Form.Group>
                        <Form.Group controlId="formBasicEmail" className="col col-sm-4">
                            <Form.Label>Product Price</Form.Label>
                            <Form.Control type="number" name="last_name" onChange={e => this.setState({ productPrice: e.target.value })} className="form-control" />
                        </Form.Group>

                        <Form.Group controlId="formGridCheckbox" className="col col-sm-2">
                            <Form.Label>Category</Form.Label>
                            <Form.Select defaultValue="Choose..." className="form-control" name="menu" onChange={e => this.setState({ category: e.target.value })}>
                                <option value="Choose...">Choose...</option>
                                <option value="HouseKeeping">HouseKeeping</option>
                                <option value="Kirana">Kirana</option>
                                <option value="Medical">Medical</option>
                                <option value="Ecommerce">Ecommerce</option>
                            </Form.Select>

                        </Form.Group>
                        {this.state.loading ? <LoadingSpinner /> :this.handleSubmit}
                        <button type="submit" class="btn btn-primary col col-sm-2"  >Add product</button>

                    </Row>

                </form>

                <div className="App">

                    <center>


                        <MDBCol md="6">
                            <input className="form-control" type="text" placeholder="Search" onChange={(e) => this.setState({ searchInput: e.target.value })} value={this.state.searchInput} aria-label="Search" />
                            <button type="button" className="btn btn-primary" onClick={(e) => this.setState({ searchInput: "" })}>Clear</button>
                        </MDBCol>

                        <Table striped bordered hover>
                            <thead>
                                <tr>
                                    <th>name</th>
                                    <th>price</th>
                                    <th>category</th>
                                </tr>
                            </thead>

                            <tbody>

                                {
                                    this.state.data.length > 0 && this.state.data.map((dataObj, index) => (
                                        <tr>
                                            <td>{dataObj.productName}</td>
                                            <td>{dataObj.productPrice}</td>
                                            <td> {dataObj.category}</td>

                                        </tr>
                                    ))
                                }
                            </tbody>
                        </Table>
                    </center>

                </div>

            </>
        )
    }
}

export default ProductClass