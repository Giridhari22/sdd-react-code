import 'bootstrap/dist/css/bootstrap.min.css';
import { Form, Row } from 'react-bootstrap';
// import { useState } from 'react';
import axios from 'axios';
import LoadingSpinner from "./LoadingSpinner";
import Table from 'react-bootstrap/Table';
// import Button from 'react-bootstrap/Button';
import React, { useState, useEffect } from "react";
import { MDBCol } from "mdbreact";





function ProductFunc(props) {
    const url = "http://localhost:5000/api/getProducts";
    const [data, setData] = useState([])
    const [searchInput, setSearchInput] = useState('');
    const [productName, setProductName] = useState('');
    const [productPrice, setProductPrice] = useState('');
    const [category, setCategory] = useState('');
    const [loading, setLoading] = useState(false);






    // const [productID, setProductId] = useState()





    const handleSubmit = (event) => {
        event.preventDefault();
        setLoading(true);
        // jo backend se data aayega usko rakhega wo
        axios.post('http://localhost:5000/api/addProducts', { productName, productPrice, category })
            .then(res => {
                console.log(res)
                fetchInfo();
                setLoading(false);
            })
            .catch(()=> {console.log("err");
            setLoading(false);
    });

        setTimeout(() => {
            setLoading(false)
        }, 2000)

    }




    const fetchInfo = () => {
        return axios.get(url)
            .then((response) => {
                console.log(response.data);
                setData(response.data.data)
            }).catch((err) => console.log(err))
    }

    useEffect(() => {
        fetchInfo();
    }, []);



    useEffect(() => {
        const searchProduct = async () => {
            try {
                const res = await axios.get(`http://localhost:5000/api/searchapi?productName=${searchInput.toLowerCase()}`);
                setData(res.data.products)
            } catch (error) {
                console.log(error)
            }
        }
        searchProduct()
    }, [searchInput])



    return (
        <>
        <center><h1>Function based components</h1></center>
            
            <form className="container mt-3 mb-3" onSubmit={handleSubmit}>
                <Row className="mb-3">
                    <Form.Group controlId="formBasicEmail" className="col col-sm-4">
                        <Form.Label>Product Name</Form.Label>
                        <Form.Control type="name" name="first_name" onChange={e => setProductName(e.target.value)} className="form-control" />
                    </Form.Group>
                    <Form.Group controlId="formBasicEmail" className="col col-sm-4">
                        <Form.Label>Product Price</Form.Label>
                        <Form.Control type="number" name="last_name" onChange={e => setProductPrice(e.target.value)} className="form-control" />
                    </Form.Group>

                    <Form.Group controlId="formGridCheckbox" className="col col-sm-2">
                        <Form.Label>Category</Form.Label>
                        <Form.Select defaultValue="Choose..." className="form-control" name="menu" onChange={e => setCategory(e.target.value)}>
                            <option value="Choose...">Choose...</option>
                            <option value="HouseKeeping">HouseKeeping</option>
                            <option value="Kirana">Kirana</option>
                            <option value="Medical">Medical</option>
                            <option value="Ecommerce">Ecommerce</option>
                        </Form.Select>

                    </Form.Group>
                    {loading ? <LoadingSpinner /> : fetchInfo}
                    <button type="submit" class="btn btn-primary btn-sm col col-sm-1.5"  disabled={loading}>
                        Add product</button>

                </Row>

            </form>






            <div className="App">

                <center>


                    <MDBCol md="6">
                        <label>search your product</label>
                        <input className="form-control" type="text" placeholder="Search" onChange={(e) => setSearchInput(e.target.value)} value={searchInput} aria-label="Search" />
                        <button type="button" className="btn btn-primary  " onClick={(e) => setSearchInput("")}>Clear</button>
                    </MDBCol>
 
                    <Table striped bordered hover>
                        <thead>
                            <tr>
                                <th>name</th>
                                <th>price</th>
                                <th>category</th>
                                <th>Edit</th>
                            </tr>
                        </thead>

                        <tbody>

                            {
                                data.length > 0 && data.map((dataObj, index) => (
                                    <tr>
                                        <td>{dataObj.productName}</td>
                                        <td>{dataObj.productPrice}</td>
                                        <td> {dataObj.category}</td>


                                    </tr>
                                ))
                            }
                        </tbody>
                    </Table>
                </center>

            </div>


        </>
    )
}

export default ProductFunc