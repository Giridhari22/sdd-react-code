import React, {  useState } from 'react';
import ClassCalculator from './components/class';
import Calculator from './components/function';




const App = () => {
  const [isClassComponent, setIsClassComponent] = useState(true);

  const toggleComponent = () => {
    setIsClassComponent(!isClassComponent);
  };

  return (
    <div>
      {isClassComponent ? (
        <ClassCalculator />
      ) : (
        <Calculator />
      )}
      

      <button type="button" class="btn btn-primary" onClick={toggleComponent}>Switch Component</button>
    </div>
  );
};

export default App;